

          <!-- /.content -->
        </div><!-- /.container -->
      </div><!-- /.content-wrapper -->
      <footer class="main-footer">
        <div class="container">
          <div class="pull-right hidden-xs">
            <b>Version</b> 1.0
          </div>
        <strong>2015 &copy; BEEP INTEGRATED LOGISTICS INFORMATION SYSTEM</strong>
        </div><!-- /.container -->
      </footer>
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.4 -->
     <?php echo $js; ?>
    <script type="text/javascript">
      $('.sk-circle , .spinner-cont')
      .hide()
      .ajaxStart(function() {
          $(this).show();
      }).ajaxStop(function() {
          $(this).hide();
      });
    </script>
      

  </body>
</html>
