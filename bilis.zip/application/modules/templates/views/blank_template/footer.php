
		<!-- jQuery 2.1.4 -->
		<script src="<?php echo base_url(); ?>assets/libs/jQuery/jQuery-2.1.4.min.js"></script>
		<!-- Bootstrap 3.3.5 -->
		<script src="<?php echo base_url(); ?>assets/libs/bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>