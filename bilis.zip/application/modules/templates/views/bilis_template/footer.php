	</div><!-- end of wrapper -->
    
    <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 1.0
        </div>
        <strong>2015 &copy; BEEP INTEGRATED LOGISTICS INFORMATION SYSTEM</strong>
    </footer>

<?php echo $js; ?>

  </body>
</html>
