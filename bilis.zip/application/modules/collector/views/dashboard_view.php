<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1 style="color:#3C8DBC;">
    <i class="fa fa-home"> Home</i>
  </h1>
</section>
<!-- Main content -->
<section class="content">
  <div class="col-md-12">
    <!-- Widget: user widget style 1 -->
    <div class="box box-widget widget-user">
      <!-- Add the bg color to the header using any of the bg-* classes -->
      <div class="widget-user-header bg-aqua-active">
        <h3 class="widget-user-username">test</h3>
        <h5 class="widget-user-desc">test</h5>
      </div>
      <div class="box-footer">
        <div class="row">
          <div class="col-sm-12">
            <div class="text-left">
              <h4 class="description-header">Welcome test to your personal page.</h4>
              </br>
              <span class="description-text">For any problem in the system, contact System Administrator for details. Click the Main Navigation to select operation. It is recommended to logout by clicking the logout button in the upper right of your page everytime you leave your Tablet or PC.</span>
            </div><!-- /.description-block -->
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div>
    </div><!-- /.widget-user -->
  </div>
</section><!-- /.content -->
</div><!-- /.content-wrapper -->